sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("re.productivityreport.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);