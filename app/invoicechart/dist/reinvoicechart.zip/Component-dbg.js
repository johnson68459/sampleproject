sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("re.invoicechart.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);