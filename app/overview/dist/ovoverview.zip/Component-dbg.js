sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("ov.overview.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);