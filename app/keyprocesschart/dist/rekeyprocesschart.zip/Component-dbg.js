sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("re.keyprocesschart.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);