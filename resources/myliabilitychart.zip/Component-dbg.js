sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("my.liabilitychart.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);