sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("re.agingchart.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);